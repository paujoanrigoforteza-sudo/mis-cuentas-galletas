MisCuentas 1.9.12

Cambios: corrección de unidades a 60 €/unidad y 30 €/media unidad; validación de importes no estándar en el mismo formulario de voz; cabecera con frames de transparencia selectiva y rastro de harina original; recordatorio de WhatsApp con GIF de carga y sonido de corredera.

Versión Android: versionCode 38 / versionName 1.9.12.
Sonido de reclamación WhatsApp: recurso local app/src/main/assets/sounds/reclamar_carga.mp3; funciona sin conexión y sustituye la URL remota anterior.
