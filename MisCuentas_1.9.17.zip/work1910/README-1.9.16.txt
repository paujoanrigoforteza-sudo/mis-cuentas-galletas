MisCuentas 1.9.16 (versionCode 42)

Cambios de esta versión:
- Animaciones de compra y venta sin emojis ni elementos flotantes.
- Recorridos diagonales descendentes hacia la zona inferior central de la pantalla.
- Efectos de sonido iniciados antes del movimiento del pollito.
- Registro por voz: si el importe reconocido no corresponde a una cantidad estándar, se muestran por separado el importe en euros y la cantidad de producto (admite medias unidades); requiere revisar y confirmar antes de guardar.
- Basada en MisCuentas 1.9.15, conservando los datos y funciones existentes.
