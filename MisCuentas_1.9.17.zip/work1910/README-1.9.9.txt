MisCuentas 1.9.9 – proyecto Android

Base: MisCuentas 1.9.7 corregida (build 1.9.7-v33).
Application ID: com.pau.miscuentas
versionCode: 34
versionName: 1.9.9

Cambios de esta versión:
- Se amplía la ventana emergente del registro por voz del widget del 68% al 84% de la altura de pantalla.
- El formulario del widget ahora permite desplazamiento vertical cuando el contenido supera el espacio disponible.
- Los controles del formulario conservan su tamaño y el botón de confirmar permanece accesible al desplazarse.
- Se mantiene el diseño compacto del pollito, el botón del widget y las mejoras de interpretación de voz de la 1.9.7.
- No se modifican las reglas de ventas, cobros, stock ni clientes.

Compilación: GitHub Actions mediante .github/workflows/android.yml.
Artifact esperado: MisCuentas-1.9.9-v34.

Pendiente de verificación: compilar con Android SDK y probar el formulario en el dispositivo real, incluyendo el caso de creación de un cliente nuevo.
