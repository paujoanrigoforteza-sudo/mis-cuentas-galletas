MisCuentas 1.9.6 (versionCode 32)

Cambios de esta versión:
- Reinicio seguro del reconocimiento de voz para permitir volver a pulsar el micrófono sin tener que cancelar manualmente.
- Protección frente a callbacks tardíos de sesiones de voz anteriores.
- Gestión unificada de errores de voz para restablecer el panel del widget y el botón del micrófono.
- Ajustes del WebView y de la ventana emergente del widget para evitar el renderizado negro en algunos dispositivos.
- Panel del widget más compacto para reducir el desplazamiento.

Compilación: GitHub Actions, workflow .github/workflows/android.yml.
APK esperado: MisCuentas-1.9.6-v32.apk
