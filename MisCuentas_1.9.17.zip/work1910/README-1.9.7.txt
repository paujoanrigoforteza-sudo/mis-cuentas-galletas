MisCuentas 1.9.7 – proyecto Android

Base: MisCuentas 1.9.6.
Application ID: com.pau.miscuentas
versionCode: 33
versionName: 1.9.7

Cambios de esta versión:
- Interpretación de voz de cantidades pequeñas como unidades (1–10), a 30 € por unidad.
- "Pau DB1" se interpreta como "Pau debe 1": venta de 1 unidad (30 €), pendiente de cobro.
- "Pau paga 2" y el error de dictado conocido "Pau pagados" se interpretan como venta de 2 unidades (60 €), no como cobro de 2 €.
- Para registrar cobros por voz se requiere una expresión explícita de pago recibido o indicar euros (por ejemplo, "Pau ha pagado 30 euros").
- Se procesan todas las alternativas devueltas por el reconocimiento de voz de Android, no solo la primera.
- El formulario de voz del widget usa renderizado WebView hardware y una pantalla de respaldo clara si falla la carga.
- El botón compacto del widget usa la ilustración adjunta del pollito con auriculares, gafas y micrófono.

Compilación:
- Abrir el proyecto en Android Studio o ejecutar: gradle clean assembleDebug
- También se incluye .github/workflows/android.yml para compilar mediante GitHub Actions.

Nota de pruebas:
- Se ha validado la sintaxis JavaScript y las reglas principales del parser con pruebas locales.
- En este entorno no hay Gradle/Android SDK disponible, por lo que la APK aún debe compilarse en GitHub Actions y probarse en el móvil.
