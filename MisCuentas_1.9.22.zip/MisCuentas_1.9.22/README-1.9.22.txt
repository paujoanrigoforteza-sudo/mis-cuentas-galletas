MisCuentas 1.9.22
Version code: 48
Base: MisCuentas 1.9.20

Cambios:
- Dos widgets Android independientes: esfera de deuda y esfera de voz.
- El widget de deuda abre el resumen emergente de clientes deudores.
- El widget de voz abre MisCuentas y activa el registro por voz.
- El widget de voz muestra el pollito con auriculares y cuaderno, sin textos de la pantalla de escucha.
- GIF de cabecera rehecho a 539x177 con transparencia, pollito completo y estela de harina clara.
- Se mantiene el resto del proyecto y sus recursos de la versión base.

La compilación debe confirmarse mediante GitHub Actions.
