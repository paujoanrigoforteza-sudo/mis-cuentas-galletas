package com.pau.miscuentas;

import android.Manifest;
import androidx.fragment.app.FragmentActivity;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import java.util.concurrent.Executor;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.JsResult;
import android.app.AlertDialog;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient.FileChooserParams;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.RecognitionListener;
import android.widget.Toast;
import android.os.Build;
import org.json.JSONObject;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends FragmentActivity {
    public static final String EXTRA_WIDGET_VOICE = "extra_widget_voice";
    public static final String EXTRA_WIDGET_DEBTS = "extra_widget_debts";
    private boolean pendingWidgetDebts = false;
    private boolean pendingWidgetVoice = false;
    private static final int REQ_MIC = 41;
    private static final int REQ_SPEECH = 42;
    private static final int REQ_CREATE_BACKUP = 43;
    private static final int REQ_IMPORT_FILE = 44;
    private static final int REQ_BACKUP_FOLDER = 45;
    private WebView web;
    private boolean waitingForSpeech = false;
    private SpeechRecognizer speechRecognizer;
    private SpeechRecognizer speechRecognizer;
    private boolean unlocked = false;
    private boolean authPromptActive = false;
    private boolean pageReady = false;
    private boolean relockOnResume = false;
    private String pendingBackupJson;
    private ValueCallback<Uri[]> fileChooserCallback;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        pendingWidgetVoice = getIntent() != null && getIntent().getBooleanExtra(EXTRA_WIDGET_VOICE, false);
        pendingWidgetDebts = getIntent() != null && getIntent().getBooleanExtra(EXTRA_WIDGET_DEBTS, false);
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setDatabaseEnabled(true);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return openExternalUrl(url);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest request) {
                return openExternalUrl(request.getUrl().toString());
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onJsAlert(WebView view, String url, String message, JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                    .setTitle("MisCuentas")
                    .setMessage(message)
                    .setPositiveButton("Aceptar", (dialog, which) -> result.confirm())
                    .setOnCancelListener(dialog -> result.cancel())
                    .show();
                return true;
            }
            @Override public boolean onJsConfirm(WebView view, String url, String message, JsResult result) {
                new AlertDialog.Builder(MainActivity.this)
                    .setTitle("Confirmar operación")
                    .setMessage(message)
                    .setPositiveButton("Confirmar", (dialog, which) -> result.confirm())
                    .setNegativeButton("Cancelar", (dialog, which) -> result.cancel())
                    .setOnCancelListener(dialog -> result.cancel())
                    .show();
                return true;
            }
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileChooserCallback != null) fileChooserCallback.onReceiveValue(null);
                fileChooserCallback = callback;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                try {
                    startActivityForResult(Intent.createChooser(intent, "Seleccionar copia de seguridad"), REQ_IMPORT_FILE);
                } catch (Exception e) {
                    fileChooserCallback = null;
                    callback.onReceiveValue(null);
                    Toast.makeText(MainActivity.this, "No se ha podido abrir el selector de archivos.", Toast.LENGTH_LONG).show();
                }
                return true;
            }
        });
        web.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        setContentView(web);
        // Siempre carga la pantalla protegida desde cero; los datos de la app se conservan en localStorage.
        web.loadUrl("file:///android_asset/index.html");
        pageReady = true;
    }


    @Override protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (intent != null && intent.getBooleanExtra(EXTRA_WIDGET_VOICE, false)) {
            pendingWidgetVoice = true;
            if (unlocked) launchWidgetVoice();
        }
        if (intent != null && intent.getBooleanExtra(EXTRA_WIDGET_DEBTS, false)) {
            pendingWidgetDebts = true;
            if (unlocked) launchWidgetDebts();
        }
    }

    private void launchWidgetVoice() {
        if (!pendingWidgetVoice) return;
        pendingWidgetVoice = false;
        callJs("if(typeof startVoice==='function'){startVoice();}");
    }

    private void launchWidgetDebts() {
        if (!pendingWidgetDebts) return;
        pendingWidgetDebts = false;
        callJs("if(typeof showDebtListModal==='function'){showDebtListModal();}");
    }

    private boolean openExternalUrl(String url) {
        if (url == null) return false;
        Uri uri = Uri.parse(url);
        String host = uri.getHost();
        if (host != null && (host.equalsIgnoreCase("wa.me") || host.endsWith(".whatsapp.com") || host.equalsIgnoreCase("whatsapp.com"))) {
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
            } catch (Exception e) {
                Toast.makeText(this, "No se ha podido abrir WhatsApp. Comprueba que esté instalado.", Toast.LENGTH_LONG).show();
            }
            return true;
        }
        return false;
    }

    private class AndroidBridge {
        @JavascriptInterface public void startVoice() {
            runOnUiThread(() -> {
                waitingForSpeech = true;
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
                } else {
                    launchSpeech();
                }
            });
        }

        @JavascriptInterface public void exportBackup(String json) {
            runOnUiThread(() -> {
                if (json == null || json.trim().isEmpty()) {
                    Toast.makeText(MainActivity.this, "No hay datos para exportar.", Toast.LENGTH_LONG).show();
                    return;
                }
                pendingBackupJson = json;
                Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("application/json");
                intent.putExtra(Intent.EXTRA_TITLE, "mis-cuentas-copia-" + new java.text.SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).format(new java.util.Date()) + ".json");
                try {
                    startActivityForResult(intent, REQ_CREATE_BACKUP);
                } catch (Exception e) {
                    pendingBackupJson = null;
                    Toast.makeText(MainActivity.this, "No se ha podido abrir dónde guardar la copia.", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface public void updateDebtWidget(double total, int clients) {
            runOnUiThread(() -> DebtWidgetProvider.updateWidgets(MainActivity.this, Math.max(0, total), Math.max(0, clients)));
        }
        @JavascriptInterface public void updateDebtReminders(String debtsJson, String settingsJson) {
            runOnUiThread(() -> {
                try {
                    JSONObject cfg=new JSONObject(settingsJson==null?"{}":settingsJson);
                    getSharedPreferences("miscuentas_reminders",MODE_PRIVATE).edit()
                        .putString("debts",debtsJson==null?"[]":debtsJson)
                        .putBoolean("enabled",cfg.optBoolean("notifyEnabled",false))
                        .putInt("minAge",cfg.optInt("notifyAge",7))
                        .putInt("every",cfg.optInt("notifyEvery",1))
                        .putString("hour",cfg.optString("notifyHour","10:00"))
                        .putBoolean("autoBackup",cfg.optBoolean("autoBackup",false)).apply();
                    if(cfg.optBoolean("notifyEnabled",false) && Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) {
                        android.content.SharedPreferences pp=getSharedPreferences("miscuentas_reminders",MODE_PRIVATE);
                        if(!pp.getBoolean("askedPermission",false)) { pp.edit().putBoolean("askedPermission",true).apply(); requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},46); }
                    }
                    DebtReminderReceiver.schedule(MainActivity.this);
                } catch(Exception e) { }
            });
        }
        @JavascriptInterface public void chooseBackupFolder() {
            runOnUiThread(() -> {
                Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
                try { startActivityForResult(intent,REQ_BACKUP_FOLDER); }
                catch(Exception e) { Toast.makeText(MainActivity.this,"No se ha podido elegir la carpeta.",Toast.LENGTH_LONG).show(); }
            });
        }
        @JavascriptInterface public void saveLocalAutoBackup(String json) {
            try { getSharedPreferences("miscuentas_reminders",MODE_PRIVATE).edit().putString("backupJson",json==null?"":json).putBoolean("autoBackup",true).apply(); } catch(Exception ignored) { }
        }
        @JavascriptInterface public void scheduleDebtReminders() { DebtReminderReceiver.schedule(MainActivity.this); }
        @JavascriptInterface public void requestNotificationPermission() {
            runOnUiThread(() -> {
                if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) {
                    getSharedPreferences("miscuentas_reminders",MODE_PRIVATE).edit().putBoolean("askedPermission",true).apply();
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},46);
                }
            });
        }
        @JavascriptInterface public void testDebtNotification(String debtJson) {
            // La prueba usa el mismo formato y la misma acción de reclamación que el aviso automático.
            runOnUiThread(() -> {
                if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},46);
                    Toast.makeText(MainActivity.this,"Autoriza las notificaciones y vuelve a pulsar Probar.",Toast.LENGTH_LONG).show();
                    return;
                }
                Intent i=new Intent(MainActivity.this,DebtReminderReceiver.class).setAction(DebtReminderReceiver.ACTION_TEST);
                i.putExtra(DebtReminderReceiver.EXTRA_TEST_DEBT, debtJson == null ? "{}" : debtJson);
                sendBroadcast(i);
            });
        }

        @JavascriptInterface public void openWhatsApp(String phone, String message) {
            runOnUiThread(() -> launchWhatsApp(phone, message));
        }

        @JavascriptInterface public void authenticateBiometric() {
            runOnUiThread(() -> showBiometricPrompt());
        }

        @JavascriptInterface public void checkPassword(String password) {
            boolean ok = "554040".equals(password == null ? "" : password);
            runOnUiThread(() -> {
                if (ok) {
                    unlocked = true;
                    callJs("window.onPasswordResult && window.onPasswordResult(true)");
                    launchWidgetVoice();
                    launchWidgetDebts();
                } else {
                    callJs("window.onPasswordResult && window.onPasswordResult(false)");
                }
            });
        }
    }

    private void callJs(String js) {
        if (web != null) web.post(() -> web.evaluateJavascript(js, null));
    }

    private void showBiometricPrompt() {
        if (authPromptActive) return;
        int status = BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK);
        if (status != BiometricManager.BIOMETRIC_SUCCESS) {
            callJs("window.onBiometricResult && window.onBiometricResult(false, 'Huella no disponible o no configurada. Usa la contraseña.')");
            return;
        }
        Executor executor = ContextCompat.getMainExecutor(this);
        BiometricPrompt prompt = new BiometricPrompt(this, executor, new BiometricPrompt.AuthenticationCallback() {
            @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                authPromptActive = false;
                unlocked = true;
                callJs("window.onBiometricResult && window.onBiometricResult(true, '')");
                launchWidgetVoice();
                launchWidgetDebts();
            }
            @Override public void onAuthenticationError(int errorCode, CharSequence errString) {
                authPromptActive = false;
                callJs("window.onBiometricResult && window.onBiometricResult(false, " + jsString(errString == null ? "Autenticación cancelada" : errString.toString()) + ")");
            }
            @Override public void onAuthenticationFailed() {
                callJs("window.onBiometricResult && window.onBiometricResult(false, 'Huella no reconocida. Inténtalo de nuevo o usa la contraseña.')");
            }
        });
        BiometricPrompt.PromptInfo info = new BiometricPrompt.PromptInfo.Builder()
                .setTitle("Desbloquear MisCuentas")
                .setSubtitle("Confirma tu identidad con la huella")
                .setNegativeButtonText("Cancelar")
                .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK)
                .build();
        authPromptActive = true;
        prompt.authenticate(info);
    }

    private String jsString(String value) {
        return org.json.JSONObject.quote(value).replace("\\u2028", " ").replace("\\u2029", " ");
    }


    private void launchWhatsApp(String phone, String message) {
        if (phone == null || phone.trim().isEmpty()) {
            Toast.makeText(this, "El cliente no tiene un teléfono válido.", Toast.LENGTH_LONG).show();
            return;
        }
        String digits = phone.replaceAll("[^0-9]", "");
        Uri uri = Uri.parse("https://wa.me/" + digits + "?text=" + Uri.encode(message == null ? "" : message));
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        try {
            intent.setPackage("com.whatsapp");
            startActivity(intent);
            return;
        } catch (Exception ignored) { }
        try {
            intent.setPackage("com.whatsapp.w4b");
            startActivity(intent);
            return;
        } catch (Exception ignored) { }
        try {
            intent.setPackage(null);
            startActivity(Intent.createChooser(intent, "Abrir enlace de WhatsApp"));
        } catch (Exception e) {
            Toast.makeText(this, "No se ha podido abrir WhatsApp ni el navegador.", Toast.LENGTH_LONG).show();
        }
    }

    private void launchSpeech() {
        try {
            if (!SpeechRecognizer.isRecognitionAvailable(this)) {
                waitingForSpeech = false;
                callJs("window.onNativeVoiceError && window.onNativeVoiceError()");
                Toast.makeText(this, "No hay servicio de reconocimiento de voz disponible", Toast.LENGTH_LONG).show();
                return;
            }
            if (speechRecognizer != null) {
                try { speechRecognizer.destroy(); } catch (Exception ignored) { }
            }
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this);
            speechRecognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) { }
                @Override public void onBeginningOfSpeech() { }
                @Override public void onRmsChanged(float rmsdB) { }
                @Override public void onBufferReceived(byte[] buffer) { }
                @Override public void onEndOfSpeech() { }
                @Override public void onError(int error) {
                    waitingForSpeech = false;
                    callJs("window.onNativeVoiceError && window.onNativeVoiceError()");
                    if (speechRecognizer != null) {
                        try { speechRecognizer.destroy(); } catch (Exception ignored) { }
                        speechRecognizer = null;
                    }
                }
                @Override public void onResults(Bundle results) {
                    waitingForSpeech = false;
                    ArrayList<String> matches = results == null ? null :
                            results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    String spoken = (matches != null && !matches.isEmpty()) ? matches.get(0) : "";
                    if (spoken.trim().isEmpty()) {
                        callJs("window.onNativeVoiceError && window.onNativeVoiceError()");
                    } else {
                        callJs("window.onNativeVoiceResult && window.onNativeVoiceResult(" + JSONObject.quote(spoken) + ")");
                    }
                    if (speechRecognizer != null) {
                        try { speechRecognizer.destroy(); } catch (Exception ignored) { }
                        speechRecognizer = null;
                    }
                }
                @Override public void onPartialResults(Bundle partialResults) { }
                @Override public void onEvent(int eventType, Bundle params) { }
            });
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-ES");
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "es-ES");
            intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Di, por ejemplo: Dani debe 30");
            intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
            speechRecognizer.startListening(intent);
        } catch (Exception e) {
            waitingForSpeech = false;
            if (speechRecognizer != null) {
                try { speechRecognizer.destroy(); } catch (Exception ignored) { }
                speechRecognizer = null;
            }
            callJs("window.onNativeVoiceError && window.onNativeVoiceError()");
            Toast.makeText(this, "No se ha podido iniciar el reconocimiento de voz.", Toast.LENGTH_LONG).show();
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQ_MIC) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED && waitingForSpeech) launchSpeech();
            else web.evaluateJavascript("window.onNativeVoiceError && window.onNativeVoiceError()", null);
            waitingForSpeech = false;
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_CREATE_BACKUP) {
            String json = pendingBackupJson;
            pendingBackupJson = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null && json != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    if (out == null) throw new java.io.IOException("No se pudo abrir el archivo");
                    out.write(json.getBytes(java.nio.charset.StandardCharsets.UTF_8));
                    out.flush();
                    Toast.makeText(this, "Copia de seguridad guardada correctamente.", Toast.LENGTH_LONG).show();
                } catch (Exception e) {
                    Toast.makeText(this, "Error al guardar la copia de seguridad.", Toast.LENGTH_LONG).show();
                }
            }
            return;
        }
        if (requestCode == REQ_IMPORT_FILE) {
            if (fileChooserCallback != null) {
                Uri[] results = resultCode == RESULT_OK && data != null && data.getData() != null
                        ? new Uri[]{data.getData()} : null;
                fileChooserCallback.onReceiveValue(results);
                fileChooserCallback = null;
            }
            return;
        }
        if (requestCode == REQ_BACKUP_FOLDER) {
            if(resultCode==RESULT_OK && data!=null && data.getData()!=null) {
                Uri tree=data.getData();
                try {
                    int flags=data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                    getContentResolver().takePersistableUriPermission(tree,flags);
                    getSharedPreferences("miscuentas_reminders",MODE_PRIVATE).edit().putString("backupTreeUri",tree.toString()).apply();
                    Toast.makeText(this,"Carpeta de copias automáticas guardada.",Toast.LENGTH_LONG).show();
                } catch(Exception e) { Toast.makeText(this,"No se ha podido guardar el permiso de la carpeta.",Toast.LENGTH_LONG).show(); }
            }
            return;
        }
        if (requestCode == REQ_SPEECH) {
            waitingForSpeech = false;
            if (resultCode == RESULT_OK && data != null) {
                ArrayList<String> matches = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                String spoken = (matches != null && !matches.isEmpty()) ? matches.get(0) : "";
                String safe = org.json.JSONObject.quote(spoken);
                if (web != null) web.post(() -> web.evaluateJavascript("window.onNativeVoiceResult && window.onNativeVoiceResult(" + safe + ")", null));
            } else {
                if (web != null) web.post(() -> web.evaluateJavascript("window.onNativeVoiceError && window.onNativeVoiceError()", null));
            }
        }
    }

    @Override protected void onPause() {
        if (unlocked && !authPromptActive && !waitingForSpeech) relockOnResume = true;
        super.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        if (pageReady && relockOnResume && !waitingForSpeech) {
            relockOnResume = false;
            unlocked = false;
            callJs("window.lockApp && window.lockApp()");
            callJs("setTimeout(function(){window.AndroidBridge && window.AndroidBridge.authenticateBiometric()},250)");
        }
    }

    @Override protected void onDestroy() {
        if (speechRecognizer != null) {
            try { speechRecognizer.cancel(); speechRecognizer.destroy(); } catch (Exception ignored) { }
            speechRecognizer = null;
        }
        super.onDestroy();
    }

    @Override protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
