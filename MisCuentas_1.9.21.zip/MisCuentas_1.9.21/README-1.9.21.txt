MisCuentas 1.9.21

- Dos widgets Android independientes: esfera de deuda y esfera de micrófono.
- La esfera de deuda muestra el total pendiente y número de clientes; al tocarla abre el listado de deudores.
- La esfera de micrófono abre el registro por voz de forma independiente.
- Se conserva la sincronización del total y el detalle de deudas desde la aplicación.
- Actualización visual del rastro de harina del pollito en cabecera.
