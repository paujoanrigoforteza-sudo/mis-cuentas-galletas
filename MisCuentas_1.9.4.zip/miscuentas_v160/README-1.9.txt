MisCuentas 1.9

Incluye animación del pollito con desplazamiento y perspectiva, elementos visuales diferenciados para venta y cobro, efectos de sonido WAV originales en app/src/main/assets/sounds y control de silencio en Ajustes. El acceso de voz del widget evita la pantalla de bloqueo de la app principal; la app principal conserva su protección biométrica. Se mantiene el GIF chick_splash.gif como recurso.

Importante: la animación utiliza la ilustración de pollito disponible en voice_chick_reference.png como personaje animado; no es un modelo 3D renderizado ni una animación frame-by-frame. El servicio de reconocimiento de voz de Android puede seguir mostrando componentes del proveedor del sistema según el dispositivo.
