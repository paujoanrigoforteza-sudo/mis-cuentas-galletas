MisCuentas 1.9.1

Cambios de esta versión:
- Registro por voz desde la interfaz propia del pollito. La actividad principal usa SpeechRecognizer nativo sin lanzar ACTION_RECOGNIZE_SPEECH ni mostrar la pantalla de Google.
- Indicador visual propio durante la escucha y el procesamiento.
- Creación de cliente desde el mismo formulario de voz: solo solicita el nombre y lo selecciona al guardarlo.
- Casilla «Fiar» en operaciones detectadas con «compra», dentro del formulario.
- Aviso «SIN STOCK DISPONIBLE» dentro del formulario, sin abrir una ventana superpuesta.
- Versión Android 1.9.1, versionCode 27.

El resto del proyecto parte de MisCuentas 1.9.
