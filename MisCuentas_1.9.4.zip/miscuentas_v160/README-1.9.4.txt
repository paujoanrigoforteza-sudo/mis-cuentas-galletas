MisCuentas 1.9.4

Cambios: reinicio seguro del reconocimiento de voz entre operaciones; interpretación de voz tolerante para cliente/acción/cantidad; ventana del widget compacta y adaptada a pantalla.

Compilar mediante GitHub Actions con el workflow android_MisCuentas_1.9.4.yml.
