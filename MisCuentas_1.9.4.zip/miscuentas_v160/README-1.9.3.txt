MisCuentas 1.9.3

Correcciones incluidas:
- El acceso de voz desde el widget fuerza la clase visual del modo widget y evita la segunda capa de escucha que la ocultaba.
- La ventana del widget inicializa el WebView con fondo visible y conserva la interfaz del pollito.
- El GIF animado del pollito escribiendo sustituye la imagen fija en las pantallas de escucha.
- Al confirmar operaciones por voz se elimina la clase voice-modal que mantenía el fondo difuminado.
- La animación de venta/cobro limpia sus elementos al finalizar.

Versión Android: versionName 1.9.3, versionCode 29.
