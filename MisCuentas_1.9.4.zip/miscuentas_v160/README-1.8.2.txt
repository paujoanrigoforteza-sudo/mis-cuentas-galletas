MisCuentas 1.8.2 – revisión sobre el proyecto 1.8.0

Cambios de esta revisión:
- El widget no fuerza la pantalla principal ni solicita automáticamente el desbloqueo de la app al abrir su ventana.
- Se elimina el forzado de mostrar la ventana sobre la pantalla de bloqueo para evitar el estado negro en algunos dispositivos.
- El flujo de voz conserva la operación pendiente durante el alta del cliente y las aclaraciones de compra/unidades.
- Los pasos de cliente nuevo, selección y aclaración usan una única capa modal con mensajes de advertencia coherentes.
- Se añade movimiento CSS de perspectiva al pollito y efectos sonoros sintetizados para venta, cobro y reclamación.
- Se conserva la autenticación biométrica disponible en la aplicación principal.
- Se conserva la lógica de copia/restauración y el almacenamiento del negocio.

Limitaciones que requieren prueba en dispositivo:
- Android puede mostrar su interfaz de reconocimiento del proveedor del servicio de voz; la captura se solicita desde la interfaz del pollito, pero el servicio de reconocimiento del sistema puede abrir su propia UI según dispositivo/versión.
- La animación de carrera es CSS sobre el arte existente, no un modelo 3D esquelético con patas articuladas.
- La imagen de pantalla de carga solicitada en la conversación no venía como archivo independiente dentro del ZIP recibido, por lo que no se ha sustituido por una imagen inventada.
- La compilación debe confirmarse en GitHub Actions y el comportamiento del widget en el móvil.


Correcciones 1.8.2: acceso independiente del widget de voz sin desbloquear la app principal; sincronización de la operación pendiente en el flujo de creación/selección de cliente; icono actualizado con la cabeza del pollito; GIF de inicio incorporado como recurso.
