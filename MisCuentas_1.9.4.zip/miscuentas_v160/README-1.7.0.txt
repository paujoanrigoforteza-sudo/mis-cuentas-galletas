MISCUENTAS 1.8.0 - pruebas parciales

Proyecto Android completo.
applicationId: com.pau.miscuentas
versionCode: 22
versionName: 1.8.0 - pruebas parciales

Novedades:
- Dashboard sencillo/completo: saldo a favor y total vendido solo aparecen en modo completo.
- Diseños compacto, panel moderno y tarjetas amplias aplicados al Dashboard.
- Efectos visuales configurables: pollito corriendo al registrar ventas; pollito con saco de dinero y monedas al registrar cobros/pagos; aviso rojo suave en deudas; flecha verde en beneficio positivo.
- Dashboard completo con gráfica de actividad de los últimos 7 días.
- Registro de venta: unidades calculadas visualmente con pollito; si el importe no coincide, ventana de confirmación para introducir unidades reales en medias unidades.
- Registro por voz: muestra cantidad calculada y pide aclaración en ventana emergente cuando el importe no coincide; se limpia el estado visual al terminar o fallar.
- Informe financiero: deuda del proveedor, deuda de clientes, cobros, dinero disponible para proveedor, saldo tras pagar proveedor y beneficio neto.
- Cobros de clientes nunca reducen la deuda con proveedor; solo los pagos al proveedor registrados expresamente la reducen.
- Riesgo rojo/amarillo/verde y simulador Resolución de deuda con aportación propia, unidades, precio ajustable, coste real por lotes y margen estimado. No registra operaciones ni modifica stock.
- Widget: tocar el importe abre una ventana independiente con deudores y acceso a WhatsApp, sin abrir/desbloquear la aplicación; el pollito mantiene el acceso al registro por voz.

Compilación: GitHub Actions, workflow .github/workflows/android.yml.


Cambios iniciales 1.8.0 - pruebas parciales:
- Formularios compactos de venta y pago con campos en paralelo y nota opcional desplegable.
- Eliminados los accesos duplicados + Movimiento y Deshacer de Últimos movimientos.
- Personalización adicional de formas de tarjetas y tipografía/tamaño.
- Añadido permiso INTERNET para permitir al servicio de reconocimiento de voz realizar conexiones cuando sean necesarias.
