MisCuentas 1.9.25
Base: proyecto MisCuentas 1.9.24.
- Sustituye la animación de cabecera por el GIF nuevo de 16 fotogramas.
- El pollito corre con las patas visibles, lleva el saco de harina con símbolo € y deja una estela de harina acumulada.
- El billete pasa de extendido a enrollado mientras el pollito avanza.
- Conserva el widget de tarjeta y el botón de voz ampliado a 88dp de la versión anterior.
Versión Android: 1.9.25 (versionCode 51).
