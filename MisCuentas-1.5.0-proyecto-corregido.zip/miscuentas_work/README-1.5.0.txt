MISCUENTAS 1.5.0

Proyecto Android completo.
applicationId: com.pau.miscuentas
versionCode: 20
versionName: 1.5.0

Novedades 1.5.0:
- Dashboard sencillo/completo: saldo a favor y total vendido solo aparecen en modo completo.
- Diseños compacto, panel moderno y tarjetas amplias aplicados al Dashboard.
- Efectos visuales: pollito corriendo al registrar ventas; pollito con saco de dinero y monedas al registrar cobros; aviso suave en tarjetas con deuda; flecha verde junto al beneficio positivo.
- Registro de venta: unidades calculadas visualmente con pollito; si el importe no coincide, ventana de confirmación para introducir unidades reales en medias unidades.
- Informe financiero reorganizado: deuda del proveedor, deuda de clientes, cobros, dinero disponible para pagar proveedor y beneficio neto.
- Los cobros de clientes nunca reducen la deuda del proveedor. Solo los pagos expresos registrados en Gastos reducen esa deuda.
- Indicador de riesgo rojo/amarillo/verde y simulador Resolución de deuda con aportación personal, unidades necesarias, ingresos y coste estimado por lote.
- El simulador no registra operaciones ni modifica el stock.

Compilación: GitHub Actions, workflow .github/workflows/android.yml.
