MisCuentas 1.2.0 - Proyecto Android

Novedades integradas en esta versión:
- Widget nativo de pantalla de inicio: deuda total y número de clientes con saldo pendiente.
- Configuración: recordatorios, copias automáticas y temas.
- Notificaciones nativas Android por cliente, con acción para reclamar por WhatsApp si tiene teléfono.
- Prueba inmediata de notificación.
- Copias automáticas diarias: selecciona una carpeta del móvil desde Configuración. Si no eliges carpeta, se conserva una copia local privada de la app.
- Temas cálido, azul, verde salvia y oscuro.
- Se mantiene la exportación/importación manual JSON.

Notas: el cálculo de antigüedad de deuda aplica los pagos cronológicamente a las ventas más antiguas. Las alarmas diarias usan AlarmManager inexacto para ahorrar batería; Android puede retrasarlas ligeramente. Las notificaciones requieren permiso en Android 13 o posterior.

El proyecto ha pasado validación estática de sintaxis JavaScript y XML. No se ha podido compilar ni probar en un teléfono real en este entorno.
