MISCUENTAS 1.3.2 - CAMBIOS INCLUIDOS

Base de trabajo: proyecto 1.3.1 facilitado por el usuario.

Novedades de esta entrega:
- Resumen de beneficio diario, últimos 7 días y mensual; el cálculo descuenta gastos y coste del consumo propio.
- Ranking de clientes ampliado con número de movimientos y fecha de última actividad.
- Aviso de stock mínimo conservado en la pestaña Mi stock.
- Nueva pestaña Gastos: registro de gastos pagados o pendientes y resumen mensual/histórico.
- Registro de consumo propio: descuenta existencias y asigna el coste real de los lotes consumidos sin crear una venta ni deuda de cliente.
- Nueva pestaña Caja: resumen diario de cobros y gastos, guardado de cierres y exportación CSV compatible con Excel.
- Deshacer: permite recuperar el estado anterior a la última operación guardada.
- Se conservan los datos existentes mediante la misma applicationId y la misma clave de almacenamiento local.
- Versión Android 1.3.2 (versionCode 17).

Validaciones realizadas: sintaxis JavaScript comprobada con Node.js; estructura del ZIP comprobada. No se ha podido ejecutar una compilación Android local en este entorno porque no hay Gradle/Android SDK instalado.

Notas: la exportación de Excel se entrega como CSV con separador de punto y coma, que puede abrirse en Excel. El botón Deshacer recupera el estado guardado inmediatamente anterior; una nueva operación reemplaza el punto de deshacer anterior.
