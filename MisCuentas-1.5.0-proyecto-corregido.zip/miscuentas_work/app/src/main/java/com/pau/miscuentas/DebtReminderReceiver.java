package com.pau.miscuentas;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import androidx.documentfile.provider.DocumentFile;
import android.os.Build;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;
import java.util.Calendar;

public class DebtReminderReceiver extends BroadcastReceiver {
    public static final String ACTION_DAILY = "com.pau.miscuentas.DAILY_DEBT_REMINDER";
    public static final String ACTION_TEST = "com.pau.miscuentas.TEST_DEBT_REMINDER";
    private static final String PREFS = "miscuentas_reminders";
    private static final String CHANNEL = "debt_reminders";
    public static final String EXTRA_TEST_DEBT = "test_debt_json";

    @Override public void onReceive(Context context, Intent intent) {
        String action = intent == null ? "" : intent.getAction();
        if (ACTION_TEST.equals(action)) {
            try {
                JSONObject d = new JSONObject(intent == null ? "{}" : intent.getStringExtra(EXTRA_TEST_DEBT));
                String name = d.optString("name", "Cliente de prueba");
                String phone = d.optString("phone", "");
                double amount = d.optDouble("amount", 25.0);
                int age = d.optInt("age", 7);
                String message = "Hola " + name + ", te escribo para recordarte que tienes un importe pendiente de " + String.format(java.util.Locale.ROOT, "%.2f", amount) + " €. ¡Gracias!";
                show(context, "Deuda pendiente: " + name,
                    "Debe " + String.format(java.util.Locale.forLanguageTag("es-ES"), "%.2f €", amount) + " · Hace " + age + " días",
                    phone, message, 90001);
            } catch (Exception e) {
                show(context, "Prueba de MisCuentas", "No se ha podido leer la deuda de prueba.", null, null, 90001);
            }
            return;
        }
        if (Intent.ACTION_BOOT_COMPLETED.equals(action)) {
            schedule(context);
            return;
        }
        if (ACTION_DAILY.equals(action)) {
            android.content.SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
            String raw = prefs.getString("debts", "[]");
            int minAge = prefs.getInt("minAge", 7);
            try {
                JSONArray debts = new JSONArray(raw);
                int shown = 0;
                long last=prefs.getLong("lastNotification",0L);
                long interval=prefs.getInt("every",1)*24L*60L*60L*1000L;
                boolean notificationDue=last==0L || System.currentTimeMillis()-last>=interval;
                for (int i=0;i<debts.length();i++) {
                    JSONObject d = debts.getJSONObject(i);
                    if (!notificationDue || d.optInt("age",0) < minAge || d.optDouble("amount",0)<=0) continue;
                    String name=d.optString("name","Cliente"), phone=d.optString("phone","");
                    double amount=d.optDouble("amount",0);
                    String message="Hola "+name+", te escribo para recordarte que tienes un importe pendiente de "+String.format(java.util.Locale.ROOT,"%.2f",amount)+" €. ¡Gracias!";
                    show(context,"Deuda pendiente: "+name, "Debe "+String.format(java.util.Locale.forLanguageTag("es-ES"),"%.2f €",amount)+" · Hace "+d.optInt("age")+" días",phone,message,1000+i);
                    shown++;
                }
                if(shown>0) prefs.edit().putLong("lastNotification",System.currentTimeMillis()).apply();
                if (prefs.getBoolean("autoBackup",false)) {
                    String backup=prefs.getString("backupJson","");
                    if (!backup.isEmpty()) {
                        try(FileOutputStream out=context.openFileOutput("miscuentas-copia-automatica.json",Context.MODE_PRIVATE)){out.write(backup.getBytes(StandardCharsets.UTF_8));}
                        String tree=prefs.getString("backupTreeUri","");
                        if(!tree.isEmpty()) try {
                            DocumentFile dir=DocumentFile.fromTreeUri(context,Uri.parse(tree));
                            if(dir!=null&&dir.canWrite()) {
                                String filename="miscuentas-copia-"+new java.text.SimpleDateFormat("yyyy-MM-dd",java.util.Locale.ROOT).format(new java.util.Date())+".json";
                                DocumentFile old=dir.findFile(filename);if(old!=null)old.delete();
                                DocumentFile file=dir.createFile("application/json",filename);
                                if(file!=null) try(java.io.OutputStream out=context.getContentResolver().openOutputStream(file.getUri())){if(out!=null)out.write(backup.getBytes(StandardCharsets.UTF_8));}
                            }
                        } catch(Exception ignored) { }
                    }
                }
            } catch(Exception ignored) { }
            schedule(context);
        }
    }
    private void show(Context c,String title,String body,String phone,String message,int id) {
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
        if(Build.VERSION.SDK_INT>=26) nm.createNotificationChannel(new NotificationChannel(CHANNEL,"Recordatorios de deudas",NotificationManager.IMPORTANCE_DEFAULT));
        Intent open=new Intent(c,MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent content=PendingIntent.getActivity(c,id,open,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,CHANNEL):new Notification.Builder(c);
        b.setSmallIcon(R.mipmap.ic_launcher).setContentTitle(title).setContentText(body).setStyle(new Notification.BigTextStyle().bigText(body)).setAutoCancel(true).setContentIntent(content);
        if(phone!=null&&!phone.trim().isEmpty()) {
            String digits=phone.replaceAll("[^0-9]", "").replaceFirst("^00", "");
            if(digits.length()==9) digits="34"+digits;
            if(digits.length()>=9) {
                Intent wa=new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/"+digits+"?text="+Uri.encode(message)));
                wa.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                PendingIntent claim=PendingIntent.getActivity(c,id+50000,wa,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
                b.addAction(new Notification.Action.Builder(android.R.drawable.ic_menu_send,"Reclamar por WhatsApp",claim).build());
            }
        }
        nm.notify(id,b.build());
    }
    public static void schedule(Context c) {
        android.content.SharedPreferences p=c.getSharedPreferences(PREFS,Context.MODE_PRIVATE);
        boolean enabled=p.getBoolean("enabled",false), autoBackup=p.getBoolean("autoBackup",false);
        Intent i=new Intent(c,DebtReminderReceiver.class).setAction(ACTION_DAILY);
        PendingIntent pi=PendingIntent.getBroadcast(c,6101,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        AlarmManager am=(AlarmManager)c.getSystemService(Context.ALARM_SERVICE);
        if(!enabled && !autoBackup) { am.cancel(pi); return; }
        String[] hm=p.getString("hour","10:00").split(":");
        Calendar cal=Calendar.getInstance();cal.set(Calendar.HOUR_OF_DAY,Integer.parseInt(hm[0]));cal.set(Calendar.MINUTE,Integer.parseInt(hm.length>1?hm[1]:"0"));cal.set(Calendar.SECOND,0);cal.set(Calendar.MILLISECOND,0);if(cal.getTimeInMillis()<=System.currentTimeMillis())cal.add(Calendar.DAY_OF_YEAR,1);
        am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(),pi);
    }
}
