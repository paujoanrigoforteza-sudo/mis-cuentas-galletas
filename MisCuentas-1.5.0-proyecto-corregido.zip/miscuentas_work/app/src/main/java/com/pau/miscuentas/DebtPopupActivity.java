package com.pau.miscuentas;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONArray;
import org.json.JSONObject;

public class DebtPopupActivity extends Activity {
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t;
    }
    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        Window w = getWindow();
        if (w != null) { w.setBackgroundDrawableResource(android.R.color.transparent); w.addFlags(WindowManager.LayoutParams.FLAG_DIM_BEHIND); WindowManager.LayoutParams a=w.getAttributes(); a.dimAmount=.58f; w.setAttributes(a); }
        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(22),dp(20),dp(22),dp(18)); card.setBackground(shape(Color.WHITE,24));
        card.addView(text("Clientes con deuda pendiente",22,Color.rgb(48,41,67),true));
        TextView sub=text("Ordenados desde la deuda más antigua.",14,Color.rgb(117,108,134),false); LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2); sp.topMargin=dp(9); sp.bottomMargin=dp(12); card.addView(sub,sp);
        ScrollView scroll=new ScrollView(this); LinearLayout rows=new LinearLayout(this); rows.setOrientation(LinearLayout.VERTICAL);
        String json=getSharedPreferences("miscuentas_widget",MODE_PRIVATE).getString("debt_details","[]");
        try {
            JSONArray arr=new JSONArray(json);
            if(arr.length()==0) rows.addView(text("No hay clientes con deuda pendiente.",15,Color.DKGRAY,false));
            for(int i=0;i<arr.length();i++) {
                JSONObject item=arr.getJSONObject(i); String name=item.optString("name","Cliente"), phone=item.optString("phone",""); double amount=item.optDouble("amount",0);
                LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(0,dp(11),0,dp(11)); row.setOrientation(LinearLayout.HORIZONTAL);
                LinearLayout info=new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL); info.setLayoutParams(new LinearLayout.LayoutParams(0,-2,1));
                info.addView(text(name,17,Color.rgb(48,41,67),true)); info.addView(text(String.format(new java.util.Locale("es","ES"),"%.2f €",amount)+" · Pendiente",14,Color.rgb(117,108,134),false)); row.addView(info);
                if(!phone.trim().isEmpty()) { Button wa=new Button(this); wa.setText("WhatsApp"); wa.setTextSize(11); wa.setAllCaps(false); wa.setTextColor(Color.rgb(23,107,66)); wa.setBackground(shape(Color.rgb(227,244,233),14)); wa.setOnClickListener(v->{ String digits=phone.replaceAll("[^0-9]",""); if(digits.length()==9)digits="34"+digits; String msg="Hola! Recordarte que tenemos pendiente "+String.format(new java.util.Locale("es","ES"),"%.2f €",amount)+"."; try{startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/"+digits+"?text="+Uri.encode(msg))));}catch(Exception ignored){} finish(); }); row.addView(wa); }
                rows.addView(row); ViewLine line=new ViewLine(this); rows.addView(line,new LinearLayout.LayoutParams(-1,dp(1)));
            }
        } catch(Exception ignored) { rows.addView(text("No se han podido leer los datos de deuda.",14,Color.DKGRAY,false)); }
        scroll.addView(rows); LinearLayout.LayoutParams rp=new LinearLayout.LayoutParams(-1,0,1); rp.topMargin=dp(3); card.addView(scroll,rp);
        Button close=new Button(this); close.setText("Cerrar"); close.setAllCaps(false); close.setTextSize(15); close.setTypeface(Typeface.DEFAULT,Typeface.BOLD); close.setTextColor(Color.rgb(80,51,33)); close.setBackground(shape(Color.rgb(234,223,213),15)); LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,dp(50)); cp.topMargin=dp(14); card.addView(close,cp); close.setOnClickListener(v->finish());
        setContentView(card); WindowManager.LayoutParams params=getWindow().getAttributes(); params.width=getResources().getDisplayMetrics().widthPixels-dp(32); params.height=Math.min(getResources().getDisplayMetrics().heightPixels-dp(120),dp(540)); getWindow().setAttributes(params);
    }
    private class ViewLine extends android.view.View { ViewLine(Activity a){super(a);setBackgroundColor(Color.rgb(227,222,232));} }
}
