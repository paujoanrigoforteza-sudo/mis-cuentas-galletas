MISCUENTAS 1.3.1 - CAMBIOS INCLUIDOS

Base: proyecto 1.2.0 facilitado por el usuario.

Cambios implementados en esta entrega:
- Nueva versión Android 1.3.1 (versionCode 16).
- Se elimina la pestaña independiente "Copia datos"; exportación/restauración y copias automáticas quedan dentro de Configuración.
- Configuración reorganizada en tarjetas: notificaciones, copias y personalización.
- Cuatro temas de color y tres diseños visuales para el panel de inicio.
- Ventanas propias de la aplicación con fondo oscurecido, esquinas redondeadas y botones coherentes.
- Alertas y confirmaciones JavaScript con diálogos Android titulados y botones claros.
- La prueba de notificación envía una notificación Android con nombre, importe y antigüedad de una deuda real; si hay teléfono registrado incluye acción "Reclamar por WhatsApp" que abre el mensaje preparado sin enviarlo.
- Widget compacto con deuda y número de clientes; el botón de pollito inicia el registro por voz después de desbloquear la aplicación.
- Se conserva la misma applicationId y el almacenamiento local existente para permitir actualización sin borrar los datos.

Comprobaciones realizadas en este entorno:
- Sintaxis JavaScript validada con Node.js.
- HTML parseado correctamente.
- Estructura del proyecto y referencias de recursos inspeccionadas.

Limitación de verificación:
- No se ha ejecutado una compilación Android local porque este entorno no dispone de Gradle ni Android SDK. El workflow android-1.3.1.yml compila y valida el proyecto en GitHub Actions.
- Las funciones ya presentes en la base 1.2.0 se conservan; esta entrega no debe interpretarse como implementación de todas las ideas futuras que aún no estaban desarrolladas en ese código.


CORRECCION DE STOCK 1.3.1:
- Registro por voz: las ventas descuentan stock en medias unidades; pagos no descuentan stock.
- Seleccion explicita de cantidad vendida cuando el importe no permite inferirla.
- Descuento de stock atomico: si no hay existencias suficientes no se modifica parcialmente el inventario.
- Edicion de ventas: recalcula asignacion y diferencia de stock; al cambiar a pago devuelve existencias.
- Borrado de ventas: devuelve exactamente las medias asignadas.
- El flujo de edicion conserva el inventario anterior si el nuevo descuento no puede realizarse.
