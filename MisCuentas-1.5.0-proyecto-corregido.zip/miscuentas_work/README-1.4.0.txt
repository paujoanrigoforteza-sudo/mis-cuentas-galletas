MISCUENTAS 1.4.0

Proyecto Android completo para compilar con GitHub Actions.

Versión: 1.4.0
versionCode: 19
applicationId: com.pau.miscuentas

Cambios integrados:
- Dashboard con resumen diario, acceso rápido a nueva operación y lista de deudas.
- Listado de clientes deudores ordenado por antigüedad y acceso individual a WhatsApp.
- Tarjetas compactas de clientes con lápiz junto al nombre y aviso de teléfono ausente.
- Selector de contenido del Dashboard: sencillo o completo.
- Mi stock dedicado a inventario, lotes, ajustes y existencias; se elimina el registro de ventas desde esa pestaña.
- Deuda con proveedor trasladada a Gastos, con ajustes, pagos e historial.
- Registro por voz: cantidades estándar calculadas automáticamente (30 € = media unidad; 60 € = una unidad; 150 € = 2,5 unidades). Para importes no estándar se solicita la cantidad real.
- Reconocimiento de voz integrado mediante SpeechRecognizer, sin salir a otra actividad y sin volver a bloquear la app al reconocer.
- Widget: tocar el área principal abre la lista de deudas; el pollito abre el registro por voz.
- Se mantienen las funciones existentes de clientes, pagos, stock, consumos, rentabilidad, ranking, avisos, copias, caja y deshacer.

Compilación:
- El workflow .github/workflows/android.yml acepta el proyecto extraído en la raíz o el ZIP completo subido al repositorio.
- GitHub Actions genera el artefacto MisCuentas-1.4.0-APK.
