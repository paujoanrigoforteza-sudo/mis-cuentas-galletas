MISCUENTAS 1.3.3

Novedades incluidas:
- Se conserva la estructura funcional de 1.3.2: clientes, ventas, pagos, saldo a favor, voz con confirmación y sugerencia de clientes similares, WhatsApp, inventario por lotes, stock mínimo, gastos, informe de rentabilidad, cierres de caja, exportación CSV y deshacer.
- Consumo propio: además del coste real asignado desde los lotes, muestra por separado la venta que se habría generado y el beneficio potencial perdido (precio de referencia: 30 € por media unidad, 60 € por unidad entera).
- Personalización ampliada a 12 paletas de color.
- Efectos visuales configurables: relieve, brillo y animación sutil de iconos.
- Tres diseños de pantalla inicial disponibles: panel moderno, tarjetas amplias y compacto.
- Ventanas emergentes con mejor contraste, esquinas redondeadas, fondo atenuado y botones táctiles más amplios.
- Widget compacto con deuda pendiente, número de clientes con deuda y acceso directo de voz mediante el pollito minimalista.
- Versión Android 1.3.3, versionCode 18, applicationId conservada: com.pau.miscuentas.

IMPORTANTE:
- El usuario ha indicado que instalará de nuevo y no necesita conservar los datos actuales. La aplicación puede empezar vacía al desinstalar/borrar los datos.
- El precio potencial del consumo propio utiliza el precio de venta configurado en la lógica actual de ventas: 30 € por media unidad.
- La exportación de movimientos se entrega como CSV con separador punto y coma, compatible con Excel.
- El archivo .github/workflows/android.yml compila directamente el proyecto extraído en la raíz del repositorio. Sube el contenido del ZIP a la raíz de GitHub (no la carpeta contenedora).
