MisCuentas 1.9.20
versionCode: 46

Novedades:
- Historial de gastos: permite editar concepto, importe, fecha y estado pagado/pendiente.
- Historial de gastos: permite eliminar movimientos con confirmación; se recalculan caja, disponible e informes.
- Historial de consumo propio: permite editar cantidad, fecha y nota. El coste real, la venta potencial y el beneficio potencial se recalculan usando el coste real de los lotes.
- Historial de consumo propio: permite eliminar movimientos con confirmación y devolver al stock las unidades asociadas al registro.
- Historial de deuda con proveedor: permite editar tipo, importe, fecha y concepto de aumentos, reducciones y pagos.
- Historial de deuda con proveedor: permite eliminar movimientos con confirmación; se recalculan deuda, dinero disponible e informes.
- Se mantiene separada la contabilidad de clientes y proveedores.
- Se conservan los datos y las funciones existentes.

Archivo de proyecto: MisCuentas_1.9.20.zip
APK que generará GitHub Actions: MisCuentas-1.9.20-v46.apk
Workflow: .github/workflows/android.yml
