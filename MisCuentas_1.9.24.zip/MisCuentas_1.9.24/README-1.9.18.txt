MisCuentas 1.9.18
versionCode: 44

Novedades:
- Nueva pantalla de bienvenida basada en la imagen animada de MisCuentas.
- Barra de progreso animada y huella visual al terminar la carga cuando el bloqueo biométrico está activado.
- Opción en Configuración para activar o desactivar el bloqueo biométrico seguro de Android.
- El bloqueo biométrico queda desactivado por defecto para instalaciones nuevas.
- Si se activa, Android verifica la biometría al iniciar la app y al volver a ella después de salir.
- Si no hay biometría configurada/disponible, se informa al usuario y se ofrece la contraseña alternativa.
- Se conserva el recorrido horizontal del pollito de cabecera, con saco roto, harina y billete enrollado; se añade desvanecimiento del rastro y una pausa antes de repetir el ciclo.

Los datos existentes permanecen en el almacenamiento local de la aplicación.
