MisCuentas 1.9.19
versionCode: 45

Novedades:
- Informe didáctico de caja con desglose de cobros, ventas anteriores, aportaciones personales, gastos pagados y pagos al proveedor.
- Registro de ventas anteriores cobradas sin cliente asociado: suma a total vendido y total cobrado. La cantidad es opcional; si se indica, descuenta stock y calcula coste/beneficio real por lote.
- Registro de aportaciones de dinero propio: aumenta el disponible sin contarse como venta, cobro de cliente ni beneficio.
- El disponible se reduce por gastos ya pagados, compras/pagos al proveedor y saldos a favor de clientes. Los gastos pendientes se muestran aparte y no reducen el efectivo hasta pagarse.
- Historial de movimientos de caja.
- Los datos nuevos se incluyen en copias de seguridad y restauración.
- Se conservan las funciones existentes de Informe.
