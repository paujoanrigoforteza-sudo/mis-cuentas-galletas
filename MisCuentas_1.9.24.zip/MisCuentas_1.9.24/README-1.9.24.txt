MisCuentas 1.9.24
Base: MisCuentas 1.9.20 proporcionado por el usuario.
- Conserva la animación original del pollito, sus patas y el billete.
- Limpia el polvo oscuro y lo sustituye por harina clara, difuminada y semitransparente.
- Conserva el diseño original de la tarjeta widget.
- Amplía el botón del pollito/micrófono de 62dp a 88dp.
- Conserva la acción directa de deuda y VoicePopupActivity para el registro por voz.
Versión 1.9.24, versionCode 50.
