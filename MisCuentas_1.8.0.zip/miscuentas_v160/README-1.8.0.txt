MisCuentas 1.8.0

Base del proyecto: 1.7.0.
Cambios incluidos en esta entrega:
- Actividad independiente para el botón de voz del widget, con ventana compacta y WebView separado del inicio de la app.
- Autenticación de acceso mediante biometría o contraseña antes de registrar desde el widget.
- Reconocimiento de voz integrado en la ventana compacta y tratamiento del resultado sin abrir la pantalla principal.
- Confirmación única de operaciones; eliminadas las definiciones duplicadas de confirmVoice().
- Interpretación de «debe», «paga» y «compra», distinguiendo cobros, ventas pendientes y ventas cuyo estado de cobro debe preguntarse.
- Conversión de cantidades de producto (unidad = 60 €, media unidad = 30 €) y aclaración de cantidades ambiguas.
- Coincidencia aproximada de nombres, selección manual y alta de cliente nuevo antes de confirmar la operación.
- Se conserva la estructura de copia/restauración de seguridad y los datos de negocio.

Nota Android: la ventana flotante puede mostrarse sobre la pantalla de bloqueo según la versión y configuración del dispositivo. Android puede exigir que el permiso de micrófono se conceda previamente y el reconocimiento depende del servicio de voz instalado.
