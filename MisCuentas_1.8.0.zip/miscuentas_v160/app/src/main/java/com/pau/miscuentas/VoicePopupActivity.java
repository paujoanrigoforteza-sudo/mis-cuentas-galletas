package com.pau.miscuentas;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.Executor;

/** Compact widget entry point. It shares the app's file-origin WebView storage. */
public class VoicePopupActivity extends Activity {
    private static final int REQ_MIC = 81;
    private WebView web;
    private SpeechRecognizer recognizer;
    private boolean waitingForPermission = false;
    private boolean authActive = false;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(true);
            setTurnScreenOn(true);
        }
        getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        android.view.WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.dimAmount = 0.35f;
        lp.width = (int)(getResources().getDisplayMetrics().widthPixels * 0.94f);
        lp.height = (int)(getResources().getDisplayMetrics().heightPixels * 0.82f);
        getWindow().setAttributes(lp);

        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setDatabaseEnabled(true);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new VoiceBridge(), "AndroidBridge");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html?widgetVoice=1");
    }

    private void js(String script) {
        if (web != null) web.post(() -> web.evaluateJavascript(script, null));
    }

    private class VoiceBridge {
        @JavascriptInterface public void startVoice() {
            runOnUiThread(() -> {
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    waitingForPermission = true;
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
                } else startRecognition();
            });
        }
        @JavascriptInterface public void checkPassword(String password) {
            boolean ok = "554040".equals(password == null ? "" : password);
            js("window.onPasswordResult&&window.onPasswordResult(" + ok + ")");
        }
        @JavascriptInterface public void authenticateBiometric() { runOnUiThread(VoicePopupActivity.this::showBiometric); }
        @JavascriptInterface public void updateDebtWidget(double total, int clients) {
            runOnUiThread(() -> DebtWidgetProvider.updateWidgets(VoicePopupActivity.this, Math.max(0,total), Math.max(0,clients)));
        }
        @JavascriptInterface public void updateDebtWidgetDetails(String json) {
            getSharedPreferences("miscuentas_widget", MODE_PRIVATE).edit().putString("debt_details", json == null ? "[]" : json).apply();
        }
        @JavascriptInterface public void closeVoicePopup() { runOnUiThread(VoicePopupActivity.this::finish); }
    }

    private void showBiometric() {
        if (authActive) return;
        int status = BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK);
        if (status != BiometricManager.BIOMETRIC_SUCCESS) {
            js("window.onBiometricResult&&window.onBiometricResult(false,'Huella no disponible. Usa la contraseña.')");
            return;
        }
        Executor executor = ContextCompat.getMainExecutor(this);
        BiometricPrompt prompt = new BiometricPrompt(this, executor, new BiometricPrompt.AuthenticationCallback() {
            @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                authActive = false;
                js("window.onBiometricResult&&window.onBiometricResult(true,'')");
                js("setTimeout(function(){startVoice()},250)");
            }
            @Override public void onAuthenticationError(int code, CharSequence message) {
                authActive = false;
                String safe = org.json.JSONObject.quote(message == null ? "Autenticación cancelada" : message.toString());
                js("window.onBiometricResult&&window.onBiometricResult(false," + safe + ")");
            }
            @Override public void onAuthenticationFailed() {
                js("window.onBiometricResult&&window.onBiometricResult(false,'Huella no reconocida. Inténtalo de nuevo o usa la contraseña.')");
            }
        });
        BiometricPrompt.PromptInfo info = new BiometricPrompt.PromptInfo.Builder()
                .setTitle("Desbloquear MisCuentas")
                .setSubtitle("Confirma tu identidad para registrar la operación")
                .setNegativeButtonText("Cancelar")
                .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK)
                .build();
        authActive = true;
        prompt.authenticate(info);
    }

    private void startRecognition() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            js("window.onNativeVoiceError&&window.onNativeVoiceError('no_service')");
            return;
        }
        try {
            if (recognizer != null) recognizer.destroy();
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(new RecognitionListener() {
                @Override public void onReadyForSpeech(Bundle params) { js("voiceStatus('Escuchando… dime cliente y operación')"); }
                @Override public void onBeginningOfSpeech() { }
                @Override public void onRmsChanged(float rmsdB) { }
                @Override public void onBufferReceived(byte[] buffer) { }
                @Override public void onEndOfSpeech() { js("voiceStatus('Procesando lo que has dicho…')"); }
                @Override public void onError(int error) { js("window.onNativeVoiceError&&window.onNativeVoiceError('recognition_error')"); }
                @Override public void onResults(Bundle results) {
                    ArrayList<String> matches = results == null ? null : results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    String spoken = matches == null || matches.isEmpty() ? "" : matches.get(0);
                    js("window.onNativeVoiceResult&&window.onNativeVoiceResult(" + org.json.JSONObject.quote(spoken) + ")");
                }
                @Override public void onPartialResults(Bundle partialResults) { }
                @Override public void onEvent(int eventType, Bundle params) { }
            });
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-ES");
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "es-ES");
            intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
            recognizer.startListening(intent);
        } catch (Exception e) {
            js("window.onNativeVoiceError&&window.onNativeVoiceError('start_failed')");
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQ_MIC) {
            boolean granted = results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED;
            waitingForPermission = false;
            if (granted) startRecognition();
            else js("window.onNativeVoiceError&&window.onNativeVoiceError('permission_denied')");
        }
    }

    @Override protected void onDestroy() {
        if (recognizer != null) { recognizer.cancel(); recognizer.destroy(); recognizer = null; }
        if (web != null) { web.removeJavascriptInterface("AndroidBridge"); web.destroy(); web = null; }
        super.onDestroy();
    }
}
