MisCuentas 1.8.0 - paquete experimental

Base: proyecto 1.7.0.
Cambios aplicados en este paquete: versionCode 23, versionName 1.8.0, etiqueta de aplicación actualizada y referencia visual del pollito de voz incorporada en assets/voice_chick_reference.png.

IMPORTANTE: las funciones nuevas acordadas (actividad flotante del widget, dictado independiente, coincidencia inteligente de clientes, interpretación de operaciones y animación integrada) NO están implementadas todavía en este paquete. La referencia gráfica está incluida como recurso, no como pantalla funcional.
