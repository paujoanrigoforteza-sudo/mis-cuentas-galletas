package com.pau.miscuentas;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.widget.RemoteViews;
import java.text.NumberFormat;
import java.util.Locale;

public class DebtWidgetProvider extends AppWidgetProvider {
    private static final String PREFS = "miscuentas_widget";
    private static final String KEY_TOTAL = "pending_total";
    private static final String KEY_CLIENTS = "pending_clients";

    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) updateOne(context, manager, id);
    }

    public static void updateWidgets(Context context, double total, int clients) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
                .putString(KEY_TOTAL, NumberFormat.getCurrencyInstance(new Locale("es", "ES")).format(total))
                .putInt(KEY_CLIENTS, clients)
                .apply();
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        int[] ids = manager.getAppWidgetIds(new ComponentName(context, DebtWidgetProvider.class));
        for (int id : ids) updateOne(context, manager, id);
    }

    private static void updateOne(Context context, AppWidgetManager manager, int id) {
        android.content.SharedPreferences prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String total = prefs.getString(KEY_TOTAL, "0,00 €");
        int clients = prefs.getInt(KEY_CLIENTS, 0);
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.debt_widget);
        views.setTextViewText(R.id.widget_total, total);
        views.setTextViewText(R.id.widget_clients, clients + (clients == 1 ? " cliente con deuda" : " clientes con deuda"));
        Intent launch = new Intent(context, MainActivity.class);
        launch.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pending = PendingIntent.getActivity(context, 7001, launch,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        views.setOnClickPendingIntent(R.id.widget_root, pending);
        manager.updateAppWidget(id, views);
    }
}
