package com.pau.miscuentas;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.graphics.Color;
import android.view.View;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.fragment.app.FragmentActivity;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import java.util.ArrayList;
import java.util.Locale;
import java.util.concurrent.Executor;

/** Compact widget entry point. It shares the app's file-origin WebView storage. */
public class VoicePopupActivity extends FragmentActivity {
    private static final int REQ_MIC = 81;
    private WebView web;
    private SpeechRecognizer recognizer;
    private boolean waitingForPermission = false;
    private boolean authActive = false;
    private boolean recognitionStarting = false;
    private int recognitionGeneration = 0;
    private final Handler voiceHandler = new Handler(Looper.getMainLooper());

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        // No forzar la actividad sobre la pantalla bloqueada: evita la ventana negra
        // en dispositivos que restringen la autenticación biométrica desde widgets.
        getWindow().setBackgroundDrawableResource(android.R.color.white);
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_DIM_BEHIND);
        android.view.WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.dimAmount = 0.35f;
        lp.width = (int)(getResources().getDisplayMetrics().widthPixels * 0.92f);
        lp.height = (int)(getResources().getDisplayMetrics().heightPixels * 0.68f);
        lp.gravity = android.view.Gravity.CENTER;
        getWindow().setAttributes(lp);

        web = new WebView(this);
        web.setBackgroundColor(Color.rgb(250, 243, 235));
        // WebView en software evita pantallas negras en algunos renderizadores/GPU de Android.
        web.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setDatabaseEnabled(true);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                view.evaluateJavascript("document.body.classList.add(\"widget-voice-mode\");", null);
            }
        });
        web.addJavascriptInterface(new VoiceBridge(), "AndroidBridge");
        setContentView(web);
        web.loadUrl("file:///android_asset/index.html?widgetVoice=1");
    }

    private void js(String script) {
        if (web != null) web.post(() -> web.evaluateJavascript(script, null));
    }

    private class VoiceBridge {
        @JavascriptInterface public void startVoice() {
            runOnUiThread(() -> {
                if (recognitionStarting) return;
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    if (!waitingForPermission) {
                        waitingForPermission = true;
                        requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
                    }
                } else startRecognition();
            });
        }
        @JavascriptInterface public void stopVoice() {
            runOnUiThread(() -> { recognitionStarting = false; releaseRecognizer(true); });
        }
        @JavascriptInterface public void checkPassword(String password) {
            boolean ok = "554040".equals(password == null ? "" : password);
            js("window.onPasswordResult&&window.onPasswordResult(" + ok + ")");
        }
        @JavascriptInterface public void authenticateBiometric() { runOnUiThread(VoicePopupActivity.this::showBiometric); }
        @JavascriptInterface public void updateDebtWidget(double total, int clients) {
            runOnUiThread(() -> DebtWidgetProvider.updateWidgets(VoicePopupActivity.this, Math.max(0,total), Math.max(0,clients)));
        }
        @JavascriptInterface public void updateDebtWidgetDetails(String json) {
            getSharedPreferences("miscuentas_widget", MODE_PRIVATE).edit().putString("debt_details", json == null ? "[]" : json).apply();
        }
        @JavascriptInterface public void closeVoicePopup() { runOnUiThread(() -> { recognitionStarting = false; releaseRecognizer(true); finish(); }); }
    }

    private void showBiometric() {
        if (authActive) return;
        int status = BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK);
        if (status != BiometricManager.BIOMETRIC_SUCCESS) {
            js("window.onBiometricResult&&window.onBiometricResult(false,'Huella no disponible. Usa la contraseña.')");
            return;
        }
        Executor executor = ContextCompat.getMainExecutor(this);
        BiometricPrompt prompt = new BiometricPrompt(this, executor, new BiometricPrompt.AuthenticationCallback() {
            @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                authActive = false;
                js("window.onBiometricResult&&window.onBiometricResult(true,'')");
                js("setTimeout(function(){startVoice()},250)");
            }
            @Override public void onAuthenticationError(int code, CharSequence message) {
                authActive = false;
                String safe = org.json.JSONObject.quote(message == null ? "Autenticación cancelada" : message.toString());
                js("window.onBiometricResult&&window.onBiometricResult(false," + safe + ")");
            }
            @Override public void onAuthenticationFailed() {
                js("window.onBiometricResult&&window.onBiometricResult(false,'Huella no reconocida. Inténtalo de nuevo o usa la contraseña.')");
            }
        });
        BiometricPrompt.PromptInfo info = new BiometricPrompt.PromptInfo.Builder()
                .setTitle("Desbloquear MisCuentas")
                .setSubtitle("Confirma tu identidad para registrar la operación")
                .setNegativeButtonText("Cancelar")
                .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK)
                .build();
        authActive = true;
        prompt.authenticate(info);
    }

    private void releaseRecognizer(boolean cancel) {
        recognitionGeneration++;
        voiceHandler.removeCallbacksAndMessages(null);
        SpeechRecognizer old = recognizer;
        recognizer = null;
        if (old != null) {
            try { if (cancel) old.cancel(); } catch (Exception ignored) { }
            try { old.destroy(); } catch (Exception ignored) { }
        }
    }

    private void startRecognition() {
        if (recognitionStarting) return;
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            js("window.onNativeVoiceError&&window.onNativeVoiceError('no_service')");
            return;
        }
        // Destruye la sesión anterior antes de abrir otra; evita que un callback
        // tardío de la sesión anterior deje bloqueado el botón de escucha.
        releaseRecognizer(true);
        recognitionStarting = true;
        try {
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            final SpeechRecognizer active = recognizer;
            final int session = recognitionGeneration;
            active.setRecognitionListener(new RecognitionListener() {
                private boolean isCurrent() { return session == recognitionGeneration && recognizer == active; }
                private void finishSession() {
                    if (!isCurrent()) return;
                    recognitionStarting = false;
                    voiceHandler.postDelayed(() -> {
                        if (isCurrent()) releaseRecognizer(false);
                    }, 350);
                }
                @Override public void onReadyForSpeech(Bundle params) { if (!isCurrent()) return; js("window.onNativeVoiceStatus&&window.onNativeVoiceStatus('Escuchando… dime cliente y operación')"); }
                @Override public void onBeginningOfSpeech() { }
                @Override public void onRmsChanged(float rmsdB) { }
                @Override public void onBufferReceived(byte[] buffer) { }
                @Override public void onEndOfSpeech() { if (!isCurrent()) return; js("window.onNativeVoiceStatus&&window.onNativeVoiceStatus('Procesando lo que has dicho…')"); }
                @Override public void onError(int error) {
                    if (!isCurrent()) return;
                    finishSession();
                    js("window.onNativeVoiceError&&window.onNativeVoiceError('recognition_error')");
                }
                @Override public void onResults(Bundle results) {
                    if (!isCurrent()) return;
                    ArrayList<String> matches = results == null ? null : results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                    String spoken = matches == null || matches.isEmpty() ? "" : matches.get(0);
                    finishSession();
                    js("window.onNativeVoiceResult&&window.onNativeVoiceResult(" + org.json.JSONObject.quote(spoken) + ")");
                }
                @Override public void onPartialResults(Bundle partialResults) { }
                @Override public void onEvent(int eventType, Bundle params) { }
            });
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-ES");
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "es-ES");
            intent.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5);
            intent.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true);
            active.startListening(intent);
        } catch (Exception e) {
            recognitionStarting = false;
            releaseRecognizer(true);
            js("window.onNativeVoiceError&&window.onNativeVoiceError('start_failed')");
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQ_MIC) {
            boolean granted = results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED;
            waitingForPermission = false;
            if (granted) startRecognition();
            else { recognitionStarting = false; js("window.onNativeVoiceError&&window.onNativeVoiceError('permission_denied')"); }
        }
    }

    @Override protected void onDestroy() {
        releaseRecognizer(true);
        if (web != null) { web.removeJavascriptInterface("AndroidBridge"); web.destroy(); web = null; }
        super.onDestroy();
    }
}
