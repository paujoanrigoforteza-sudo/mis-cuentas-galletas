package com.pau.miscuentas;

import android.Manifest;
import androidx.fragment.app.FragmentActivity;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import java.util.concurrent.Executor;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.speech.RecognizerIntent;
import android.widget.Toast;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends FragmentActivity {
    private static final int REQ_MIC = 41;
    private static final int REQ_SPEECH = 42;
    private WebView web;
    private boolean waitingForSpeech = false;
    private boolean unlocked = false;
    private boolean authPromptActive = false;
    private boolean pageReady = false;
    private boolean relockOnResume = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        web = new WebView(this);
        web.getSettings().setJavaScriptEnabled(true);
        web.getSettings().setDomStorageEnabled(true);
        web.getSettings().setDatabaseEnabled(true);
        web.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return openExternalUrl(url);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, android.webkit.WebResourceRequest request) {
                return openExternalUrl(request.getUrl().toString());
            }
        });
        web.setWebChromeClient(new WebChromeClient());
        web.addJavascriptInterface(new AndroidBridge(), "AndroidBridge");
        setContentView(web);
        // Siempre carga la pantalla protegida desde cero; los datos de la app se conservan en localStorage.
        web.loadUrl("file:///android_asset/index.html");
        pageReady = true;
    }


    private boolean openExternalUrl(String url) {
        if (url == null) return false;
        Uri uri = Uri.parse(url);
        String host = uri.getHost();
        if (host != null && (host.equalsIgnoreCase("wa.me") || host.endsWith(".whatsapp.com") || host.equalsIgnoreCase("whatsapp.com"))) {
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW, uri);
                startActivity(intent);
            } catch (Exception e) {
                Toast.makeText(this, "No se ha podido abrir WhatsApp. Comprueba que esté instalado.", Toast.LENGTH_LONG).show();
            }
            return true;
        }
        return false;
    }

    private class AndroidBridge {
        @JavascriptInterface public void startVoice() {
            runOnUiThread(() -> {
                waitingForSpeech = true;
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
                } else {
                    launchSpeech();
                }
            });
        }

        @JavascriptInterface public void openWhatsApp(String phone, String message) {
            runOnUiThread(() -> launchWhatsApp(phone, message));
        }

        @JavascriptInterface public void authenticateBiometric() {
            runOnUiThread(() -> showBiometricPrompt());
        }

        @JavascriptInterface public void checkPassword(String password) {
            boolean ok = "554040".equals(password == null ? "" : password);
            runOnUiThread(() -> {
                if (ok) {
                    unlocked = true;
                    callJs("window.onPasswordResult && window.onPasswordResult(true)");
                } else {
                    callJs("window.onPasswordResult && window.onPasswordResult(false)");
                }
            });
        }
    }

    private void callJs(String js) {
        if (web != null) web.post(() -> web.evaluateJavascript(js, null));
    }

    private void showBiometricPrompt() {
        if (authPromptActive) return;
        int status = BiometricManager.from(this).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK);
        if (status != BiometricManager.BIOMETRIC_SUCCESS) {
            callJs("window.onBiometricResult && window.onBiometricResult(false, 'Huella no disponible o no configurada. Usa la contraseña.')");
            return;
        }
        Executor executor = ContextCompat.getMainExecutor(this);
        BiometricPrompt prompt = new BiometricPrompt(this, executor, new BiometricPrompt.AuthenticationCallback() {
            @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult result) {
                authPromptActive = false;
                unlocked = true;
                callJs("window.onBiometricResult && window.onBiometricResult(true, '')");
            }
            @Override public void onAuthenticationError(int errorCode, CharSequence errString) {
                authPromptActive = false;
                callJs("window.onBiometricResult && window.onBiometricResult(false, " + jsString(errString == null ? "Autenticación cancelada" : errString.toString()) + ")");
            }
            @Override public void onAuthenticationFailed() {
                callJs("window.onBiometricResult && window.onBiometricResult(false, 'Huella no reconocida. Inténtalo de nuevo o usa la contraseña.')");
            }
        });
        BiometricPrompt.PromptInfo info = new BiometricPrompt.PromptInfo.Builder()
                .setTitle("Desbloquear MisCuentas")
                .setSubtitle("Confirma tu identidad con la huella")
                .setNegativeButtonText("Cancelar")
                .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK)
                .build();
        authPromptActive = true;
        prompt.authenticate(info);
    }

    private String jsString(String value) {
        return org.json.JSONObject.quote(value).replace("\\u2028", " ").replace("\\u2029", " ");
    }


    private void launchWhatsApp(String phone, String message) {
        if (phone == null || phone.trim().isEmpty()) {
            Toast.makeText(this, "El cliente no tiene un teléfono válido.", Toast.LENGTH_LONG).show();
            return;
        }
        String digits = phone.replaceAll("[^0-9]", "");
        Uri uri = Uri.parse("https://wa.me/" + digits + "?text=" + Uri.encode(message == null ? "" : message));
        Intent intent = new Intent(Intent.ACTION_VIEW, uri);
        try {
            intent.setPackage("com.whatsapp");
            startActivity(intent);
            return;
        } catch (Exception ignored) { }
        try {
            intent.setPackage("com.whatsapp.w4b");
            startActivity(intent);
            return;
        } catch (Exception ignored) { }
        try {
            intent.setPackage(null);
            startActivity(Intent.createChooser(intent, "Abrir enlace de WhatsApp"));
        } catch (Exception e) {
            Toast.makeText(this, "No se ha podido abrir WhatsApp ni el navegador.", Toast.LENGTH_LONG).show();
        }
    }

    private void launchSpeech() {
        try {
            Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-ES");
            intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Di, por ejemplo: Dani debe 30");
            startActivityForResult(intent, REQ_SPEECH);
        } catch (Exception e) {
            if (web != null) web.post(() -> web.evaluateJavascript("window.onNativeVoiceError && window.onNativeVoiceError()", null));
            Toast.makeText(this, "No hay servicio de reconocimiento de voz disponible", Toast.LENGTH_LONG).show();
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == REQ_MIC) {
            if (results.length > 0 && results[0] == PackageManager.PERMISSION_GRANTED && waitingForSpeech) launchSpeech();
            else web.evaluateJavascript("window.onNativeVoiceError && window.onNativeVoiceError()", null);
            waitingForSpeech = false;
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_SPEECH) {
            if (resultCode == RESULT_OK && data != null) {
                ArrayList<String> matches = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                String spoken = (matches != null && !matches.isEmpty()) ? matches.get(0) : "";
                String safe = org.json.JSONObject.quote(spoken);
                if (web != null) web.post(() -> web.evaluateJavascript("window.onNativeVoiceResult && window.onNativeVoiceResult(" + safe + ")", null));
            } else {
                if (web != null) web.post(() -> web.evaluateJavascript("window.onNativeVoiceError && window.onNativeVoiceError()", null));
            }
        }
    }

    @Override protected void onPause() {
        if (unlocked && !authPromptActive) relockOnResume = true;
        super.onPause();
    }

    @Override protected void onResume() {
        super.onResume();
        if (pageReady && relockOnResume) {
            relockOnResume = false;
            unlocked = false;
            callJs("window.lockApp && window.lockApp()");
            callJs("setTimeout(function(){window.AndroidBridge && window.AndroidBridge.authenticateBiometric()},250)");
        }
    }

    @Override protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        web.saveState(out);
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
